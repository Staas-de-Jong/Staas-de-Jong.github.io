<html>

  <head> <title> A basic example: server side </title> </head>

  <body>

    <?php
  
      $textInput = $_GET['textInput'];

      file_put_contents ("datalog.txt", $textInput . "\n", FILE_APPEND);

      echo 'Done processing.';

    ?>

  </body>

</html>
