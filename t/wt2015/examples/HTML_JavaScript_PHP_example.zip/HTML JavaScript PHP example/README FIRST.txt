
(1)
  First set up the Apache web server software, including PHP5, on your machine.

  This will give you a local directory from which web pages are served.

  On Mac OS X, this directory may be: /Users/"your user name"/Sites .
  On Linux, it may be /var/www .


(2)
  Put the server-side files in this directory, and make sure the data log file has its writing permissions enabled:
  Otherwise, the server script will be unable to actually store user input in the log file when it executes.


(3)
  Open the client side HTML file in a plaintext editor, and make sure that the form's action attribute points to the right URL on your local machine.

  On Mac OS X, this URL may be: http://localhost/~"your user name"/server_script.php .
  On Linux, it may be http://localhost/server_script.php .


(4)
  Open the updated client-side HTML file in your browser, and open the server script in a plaintext editor.

  Study and verify how the plaintext files implement a basic but complete client-server interaction:
  storing client-side user input, over the world wide web, in a server-side log file.


(Extra)
  If your machine actually is on the Internet, you can make the server accessible to other machines (on the local network).

  To do this, first find your current IP address in your operating system's user interface (e.g. "192.168.0.112").
  Then, change the client code so that the action attribute in the form points to your server's IP address, instead of to "localhost".
  For example, change to:  action="http://192.168.0.112/server_script.php"  .

  The client code can now function from other machines than the one running the server, too.

  Feel free to further change the code to see what happens.
  If things go unexpectedly wrong, you can always revert to the original copies in the zip file.

